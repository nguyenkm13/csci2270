#include "MovieInventory.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

// MovieItem: node struct that will be stored in the MovieInventory BST

MovieInventory::MovieInventory() {
  //write your code
}

MovieInventory::~MovieInventory() {
  //write your code
}

void MovieInventory::printMovieInventory() {
   //write your code
}

void MovieInventory::addMovieItem(int ranking, string title, int year, float rating) {
  //write your code
}

void MovieInventory::getMovie(string title) {
  //write your code
}

void MovieInventory::searchMovies(float rating, int year) {
  //write your code
}

void MovieInventory::averageRating() {
  //write your code
}

void MovieInventory::deleteMovieItem(string title)
{
  //write your code
}

void MovieInventory::leftRotate(string title)
{
  //write your code
}